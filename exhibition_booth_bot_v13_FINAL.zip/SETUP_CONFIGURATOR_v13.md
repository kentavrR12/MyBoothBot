# Инструкция по запуску конфигуратора (v13)

## 🎯 Что исправлено в v13:

✅ **Русский язык теперь на кириллице** (не транслит)  
✅ **Ссылки на конфигуратор теперь рабочие**  
✅ **Поддержка локального запуска конфигуратора**  
✅ **Передача параметров через URL**

---

## 📋 Вариант 1: Локальный запуск (БЫСТРО)

### Шаг 1: Запустить конфигуратор

```bash
cd /home/ubuntu/exhibition_booth_configurator
python -m http.server 8000
```

Вывод:
```
Serving HTTP on 0.0.0.0 port 8000 (http://localhost:8000/) ...
```

### Шаг 2: Обновить .env файл бота

```bash
cd /home/ubuntu/exhibition_booth_bot
# Открыть .env и заменить строку:
# CONFIGURATOR_URL=http://localhost:8000/

# Или выполнить команду:
echo "CONFIGURATOR_URL=http://localhost:8000/" >> .env
```

### Шаг 3: Запустить бот (в новом терминале)

```bash
cd /home/ubuntu/exhibition_booth_bot
python main.py
```

Вывод:
```
🤖 BOT IS RUNNING AND READY TO WORK...
📍 Configurator URL: http://localhost:8000/
```

### Шаг 4: Открыть Telegram и отправить `/start`

Теперь при нажатии "Дизайн в 3D" откроется конфигуратор!

---

## 🌐 Вариант 2: GitHub Pages (ДЛЯ ПРОДАКШЕНА)

### Шаг 1: Создать GitHub репозиторий

1. Перейди на https://github.com/new
2. Создай репозиторий `exhibition-booth-configurator`
3. Выбери "Public"

### Шаг 2: Загрузить конфигуратор

```bash
cd /home/ubuntu/exhibition_booth_configurator

# Инициализировать git
git init
git add .
git commit -m "Initial commit: 3D Booth Configurator"

# Добавить remote (замени USERNAME на свой GitHub username)
git remote add origin https://github.com/USERNAME/exhibition-booth-configurator.git

# Загрузить на GitHub
git branch -M main
git push -u origin main
```

### Шаг 3: Включить GitHub Pages

1. Перейди в Settings репозитория
2. Найди "Pages" в левом меню
3. Выбери "Deploy from a branch"
4. Выбери ветку "main" и папку "/ (root)"
5. Нажми "Save"

GitHub Pages будет доступен по адресу:
```
https://USERNAME.github.io/exhibition-booth-configurator/
```

### Шаг 4: Обновить .env бота

```bash
cd /home/ubuntu/exhibition_booth_bot

# Отредактировать .env:
CONFIGURATOR_URL=https://USERNAME.github.io/exhibition-booth-configurator/

# Или выполнить:
echo "CONFIGURATOR_URL=https://USERNAME.github.io/exhibition-booth-configurator/" >> .env
```

### Шаг 5: Перезапустить бот

```bash
python main.py
```

---

## 🚀 Вариант 3: Netlify (САМЫЙ ПРОСТОЙ)

### Шаг 1: Подключить GitHub репозиторий к Netlify

1. Перейди на https://netlify.com
2. Нажми "Add new site" → "Import an existing project"
3. Выбери GitHub
4. Выбери репозиторий `exhibition-booth-configurator`
5. Нажми "Deploy"

Netlify автоматически развернет конфигуратор!

### Шаг 2: Скопировать URL

Netlify выдаст URL вроде:
```
https://exhibition-booth-configurator.netlify.app/
```

### Шаг 3: Обновить .env бота

```bash
cd /home/ubuntu/exhibition_booth_bot
echo "CONFIGURATOR_URL=https://exhibition-booth-configurator.netlify.app/" >> .env
```

### Шаг 4: Перезапустить бот

```bash
python main.py
```

---

## 🧪 Тестирование

### Локально:

1. Открой браузер: http://localhost:8000
2. Вращай 3D стенд мышкой
3. Меняй параметры слева
4. Смотри, как обновляется цена

### В Telegram:

1. Напиши `/start`
2. Выбери язык (🇷🇺 Русский)
3. Нажми "Дизайн в 3D"
4. Откроется конфигуратор в браузере
5. Вернись в Telegram и нажми "Быстрая конфигурация"
6. Выбери параметры
7. Нажми "Рассчитать"
8. **Теперь должна появиться смета стоимости!** ✅

---

## 🐛 Если что-то не работает:

### Ошибка: "Ссылка не открывается"

- Проверь, что конфигуратор запущен: `http://localhost:8000`
- Проверь значение `CONFIGURATOR_URL` в `.env`
- Перезапусти бот: `python main.py`

### Ошибка: "Русский язык показывает транслит"

- Это была ошибка в v12, в v13 всё исправлено
- Убедись, что используешь `main_v13.py` или `main.py` (если скопировал)

### Ошибка: "Расчет не появляется"

- Смотри логи в терминале бота
- Должно быть: `✅ COST CALCULATED: Base=...`
- Если логов нет, значит обработчик не вызывается

---

## 📦 Файлы проекта:

```
/home/ubuntu/
├── exhibition_booth_bot/
│   ├── main.py (v13 - НОВЫЙ)
│   ├── main_v13.py (резервная копия)
│   ├── .env (с CONFIGURATOR_URL)
│   └── requirements.txt
│
└── exhibition_booth_configurator/
    ├── index.html
    ├── configurator.js
    └── README.md
```

---

## ✅ Готово!

Теперь у тебя есть полностью рабочая система:
- ✅ Telegram-бот с русским языком (кириллица)
- ✅ 3D конфигуратор с интерактивной визуализацией
- ✅ Расчет стоимости
- ✅ Интеграция между ботом и конфигуратором

Удачи с дипломной работой! 🎓
